# EVIL-EMAIL-SMS-BOMBER


![alt tag](https://github.com/SEODEMON/EVIL-EMAIL-SMS-BOMBER/blob/master/images/logo.png)

### By Jeff Childers

#### The EVIL EMAIL/SMS BOMBER is made for research and testing purposes only.  Prank your friends.  EVIL EMAIL/SMS BOMBER can send bulk mail or SMS text messages.
 
#### DISCLAIMER:  Use at your own risk!  I take no responsibility for your actions.  This was made for pranks, testing and investigation purposes only.
 
### SMS is Only For USA and Canada Numbers

 
![alt tag](https://github.com/SEODEMON/EVIL-EMAIL-SMS-BOMBER/blob/master/images/SCREEN_SHOT.jpg)

# Features:  
### Send Bulk Emails – Mass Emailing – Email Bombing

### Send Bulk SMS – Mass SMS Sending – SMSBombing  =  Only For USA and Canada Numbers

#### Unlimited SMTP Servers Using Free Email Providers
#### Multiple SMTP Servers Using Free Email Providers

# How To USE 

PLEASE READ THE INSTRUCTIONS IN THE PDF FILE FIRST   

https://github.com/SEODEMON/EVIL-EMAIL-SMS-BOMBER/blob/master/INSTRUCTIONS.pdf


[![IMAGE ALT TEXT HERE](https://github.com/SEODEMON/EVIL-EMAIL-SMS-BOMBER/blob/master/images/youtube.JPG)](https://www.youtube.com/watch?v=saMag6sGbV0


